<?php
return [
    'failed' => 'Email atau Password salah',
];

?>
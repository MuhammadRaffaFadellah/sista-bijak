<?php $__env->startSection('dashboard-title'); ?>
    Sista Bijak - Edit Data Penduduk
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>
<div class="container mx-auto px-4 py-6">
    <div class="card shadow-lg rounded-lg overflow-hidden">
        <div class="bg-gray-800 text-white p-4">
            <h3 class="text-lg font-bold">Edit Data Penduduk</h3>
        </div>
        <div class="p-4">
            <form action="<?php echo e(isset($penduduk) ? route('penduduk.update', $penduduk->nik) : route('penduduk.store')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <?php if(isset($penduduk)): ?>
                    <?php echo method_field('PUT'); ?>
                <?php endif; ?>
                <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <?php $__currentLoopData = ['nik', 'nama_lengkap', 'jenis_kelamin', 'tempat_lahir', 'tanggal_lahir', 'status_hubkel', 'pendidikan_terakhir', 'jenis_pekerjaan', 'agama', 'status_perkawinan', 'alamat', 'rw', 'rt', 'kelurahan', 'status_kependudukan']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $field): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div>
                            <label for="<?php echo e($field); ?>" class="block text-sm font-medium text-gray-700"><?php echo e(ucwords(str_replace('_', ' ', $field))); ?></label>
                            <?php if($field === 'nik'): ?>
                                <input type="text" name="<?php echo e($field); ?>" id="<?php echo e($field); ?>" value="<?php echo e(old($field, $penduduk->$field)); ?>" class="mt-1 block w-full border border-gray-300 rounded-md shadow-sm focus:ring focus:ring-green-500" readonly />
                                <span class="text-red-500 text-sm" id="nik-warning" style="display: none;">Tidak dapat merubah NIK</span>
                            <?php elseif($field === 'jenis_kelamin'): ?>
                                <select name="<?php echo e($field); ?>" id="<?php echo e($field); ?>" required class="mt-1 block w-full border border-gray-300 rounded-md shadow-sm focus:ring focus:ring-green-500">
                                    <option value="Laki-laki" <?php echo e(old($field, $penduduk->$field) == 'Laki-laki' ? 'selected' : ''); ?>>Laki-laki</option>
                                    <option value="Perempuan" <?php echo e(old($field, $penduduk->$field) == 'Perempuan' ? 'selected' : ''); ?>>Perempuan</option>
                                </select>
                            <?php elseif($field === 'agama'): ?>
                                <select name="<?php echo e($field); ?>" id="<?php echo e($field); ?>" required class="mt-1 block w-full border border-gray-300 rounded-md shadow-sm focus:ring focus:ring-green-500">
                                    <option value="Islam" <?php echo e(old($field, $penduduk->$field) == 'Islam' ? 'selected' : ''); ?>>Islam</option>
                                    <option value="Kristen" <?php echo e(old($field, $penduduk->$field) == 'Kristen' ? 'selected' : ''); ?>>Kristen</option>
                                    <option value="Hindu" <?php echo e(old($field, $penduduk->$field) == 'Hindu' ? 'selected' : ''); ?>>Hindu</option>
                                    <option value="Buddha" <?php echo e(old($field, $penduduk->$field) == 'Buddha' ? 'selected' : ''); ?>>Buddha</option>
                                    <option value="Konghucu" <?php echo e(old($field, $penduduk->$field) == 'Konghucu' ? 'selected' : ''); ?>>Konghucu</option>
                                </select>
                            <?php elseif($field === 'status_hubkel'): ?>
                                <select name="<?php echo e($field); ?>" id="<?php echo e($field); ?>" required class="mt-1 block w-full border border-gray-300 rounded-md shadow-sm focus:ring focus:ring-green-500">
                                    <option value="Kepala Keluarga" <?php echo e(old($field, $penduduk->$field) == 'Kepala Keluarga' ? 'selected' : ''); ?>>Kepala Keluarga</option>
                                    <option value="Istri" <?php echo e(old($field, $penduduk->$field) == 'Istri' ? 'selected' : ''); ?>>Istri</option>
                                    <option value="Anak" <?php echo e(old($field, $penduduk->$field) == 'Anak' ? 'selected' : ''); ?>>Anak</option>
                                    <option value="Famili Lain" <?php echo e(old($field, $penduduk->$field) == 'Famili Lain' ? 'selected' : ''); ?>>Famili Lain</option>
                                    <option value="Sepupu" <?php echo e(old($field, $penduduk->$field) == 'Sepupu' ? 'selected' : ''); ?>>Sepupu</option>
                                    <option value="Mertua" <?php echo e(old($field, $penduduk->$field) == 'Mertua' ? 'selected' : ''); ?>>Mertua</option>
                                    <option value="Orang Tua" <?php echo e(old($field, $penduduk->$field) == 'Orang Tua' ? 'selected' : ''); ?>>Orang Tua</option>
                                    <option value="Cucu" <?php echo e(old($field, $penduduk->$field) == 'Cucu' ? 'selected' : ''); ?>>Cucu</option>
                                    <option value="Pembantu" <?php echo e(old($field, $penduduk->$field) == 'Pembantu' ? 'selected' : ''); ?>>Pembantu</option>
                                    <option value="Lainnya" <?php echo e(old($field, $penduduk->$field) == 'Lainnya' ? 'selected' : ''); ?>>Lainnya</option>
                                </select>
                            <?php elseif($field === 'status_perkawinan'): ?>
                                <select name="<?php echo e($field); ?>" id="<?php echo e($field); ?>" required class="mt-1 block w-full border border-gray-300 rounded-md shadow-sm focus:ring focus:ring-green-500">
                                    <option value="Belum Menikah" <?php echo e(old($field, $penduduk->$field) == 'Belum Menikah' ? 'selected' : ''); ?>>Belum Menikah</option>
                                    <option value="Menikah" <?php echo e(old($field, $penduduk->$field) == 'Menikah' ? 'selected' : ''); ?>>Menikah</option>
                                    <option value="Cerai Hidup" <?php echo e(old($field, $penduduk->$field) == 'Cerai Hidup' ? 'selected' : ''); ?>>Cerai Hidup</option>
                                    <option value="Cerai Mati" <?php echo e(old($field, $penduduk->$field) == 'Cerai Mati' ? 'selected' : ''); ?>>Cerai Mati</option>
                                </select>
                            <?php elseif($field === 'jenis_pekerjaan'): ?>
                                <select name="<?php echo e($field); ?>" id="<?php echo e($field); ?>" class="mt-1 block w-full border border-gray-300 rounded-md shadow-sm focus:ring focus:ring-green-500">
                                    <option value="Tidak Bekerja" <?php echo e(old($field, $penduduk->$field) == 'Tidak Bekerja' ? 'selected' : ''); ?>>Tidak Bekerja</option>
                                    <option value="PNS" <?php echo e(old($field, $penduduk->$field) == 'PNS' ? 'selected' : ''); ?>>PNS</option>
                                    <option value="Swasta" <?php echo e(old($field, $penduduk->$field) == 'Swasta' ? 'selected' : ''); ?>>Swasta</option>
                                    <option value="Wirausaha" <?php echo e(old($field, $penduduk->$field) == 'Wirausaha' ? 'selected' : ''); ?>>Wirausaha</option>
                                    <option value="Lainnya" <?php echo e(old($field, $penduduk->$field) == 'Lainnya' ? 'selected' : ''); ?>>Lainnya</option>
                                </select>
                            <?php elseif($field === 'pendidikan_terakhir'): ?>
                                <select name="<?php echo e($field); ?>" id="<?php echo e($field); ?>" required class="mt-1 block w-full border border-gray-300 rounded-md shadow-sm focus:ring focus:ring-green-500">
                                    <option value="AKADEMI/DIPLOMA III/S.MUDA" <?php echo e(old($field, $penduduk->$field) == 'AKADEMI/DIPLOMA III/S.MUDA' ? 'selected' : ''); ?>>AKADEMI/DIPLOMA III/S.MUDA</option>
                                    <option value="BELUM TAMAT SD/SEDERAJAT" <?php echo e(old($field, $penduduk->$field) == 'BELUM TAMAT SD/SEDERAJAT' ? 'selected' : ''); ?>>BELUM TAMAT SD/SEDERAJAT</option>
                                    <option value="DIPLOMA I/II" <?php echo e(old($field, $penduduk->$field) == 'DIPLOMA I/II' ? 'selected' : ''); ?>>DIPLOMA I/II</option>
                                    <option value="DIPLOMA IV/STRATA I" <?php echo e(old($field, $penduduk->$field) == 'DIPLOMA IV/STRATA I' ? 'selected' : ''); ?>>DIPLOMA IV/STRATA I</option>
                                    <option value="SLTA/SEDERAJAT" <?php echo e(old($field, $penduduk->$field) == 'SLTA/SEDERAJAT' ? 'selected' : ''); ?>>SLTA/SEDERAJAT</option>
                                    <option value="STRATA II" <?php echo e(old($field, $penduduk->$field) == 'STRATA II' ? 'selected' : ''); ?>>STRATA II</option>
                                    <option value="STRATA III" <?php echo e(old($field, $penduduk->$field) == 'STRATA III' ? 'selected' : ''); ?>>STRATA III</option>
                                    <option value="TAMAT SD/SEDERAJAT" <?php echo e(old($field, $penduduk->$field) == 'TAMAT SD/SEDERAJAT' ? 'selected' : ''); ?>>TAMAT SD/SEDERAJAT</option>
                                    <option value="TIDAK TAMAT SD/SEDERAJAT" <?php echo e(old($field, $penduduk->$field) == 'TIDAK TAMAT SD/SEDERAJAT' ? 'selected' : ''); ?>>TIDAK TAMAT SD/SEDERAJAT</option>
                                    <option value="TIDAK/BELUM SEKOLAH" <?php echo e(old($field, $penduduk->$field) == 'TIDAK/BELUM SEKOLAH' ? 'selected' : ''); ?>>TIDAK/BELUM SEKOLAH</option>
                                </select>
                            <?php elseif($field === 'rw'): ?>
                                <select name="<?php echo e($field); ?>" id="<?php echo e($field); ?>" required class="mt-1 block w-full border border-gray-300 rounded-md shadow-sm focus:ring focus:ring-green-500">
                                    <?php if(Auth::user()->role->id === 1): ?> <!-- Admin -->
                                        <?php $__currentLoopData = $rws; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rw): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($rw->id); ?>" <?php echo e(old($field, $penduduk->$field) == $rw->id ? 'selected' : ''); ?>><?php echo e($rw->rukun_warga); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php else: ?> <!-- RW -->
                                        <option value="<?php echo e(Auth::user()->rw->id); ?>" <?php echo e(old($field, $penduduk->$field) == Auth::user()->rw->id ? 'selected' : ''); ?>><?php echo e(Auth::user()->rw->rukun_warga); ?></option>
                                    <?php endif; ?>
                                </select>
                            <?php elseif($field === 'kelurahan'): ?>
                                <input type="text" name="<?php echo e($field); ?>" id="<?php echo e($field); ?>" value="Kesambi" readonly class="mt-1 block w-full border border-gray-300 rounded-md shadow-sm focus:ring focus:ring-green-500" />
                            <?php elseif($field === 'status_kependudukan'): ?>
                                <input type="text" name="<?php echo e($field); ?>" id="<?php echo e($field); ?>" value="Masuk" readonly class="mt-1 block w-full border border-gray-300 rounded-md shadow-sm focus:ring focus:ring-green-500" />
                            <?php else: ?>
                                <input type="<?php echo e($field === 'tanggal_lahir' ? 'date' : 'text'); ?>" name="<?php echo e($field); ?>" id="<?php echo e($field); ?>" value="<?php echo e(old($field, $penduduk->$field)); ?>" class="mt-1 block w-full border border-gray-300 rounded-md shadow-sm focus:ring focus:ring-green-500" required>
                            <?php endif; ?>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <div class="mt-4 flex justify-between">
                    <a href="<?php echo e(route('resident-migration-in')); ?>" class="bg-red-500 text-white px-4 py-2 rounded hover:bg-red-600 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-red-500">Kembali</a>
                    <button type="submit" onclick="editConfirm(event)" class="bg-blue-500 text-white px-4 py-2 rounded hover:bg-blue-600 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500">
                        <?php if(isset($penduduk)): ?>
                            Update Data
                        <?php else: ?>
                            Simpan Data
                        <?php endif; ?>
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php echo $__env->make('sweetalert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<script>
    function editConfirm(event) {
        event.preventDefault(); // Mencegah submit form secara default
        Swal.fire({
            title: "Apakah kamu yakin?",
            text: "Apakah kamu ingin menyimpan perubahan?",
            icon: "question",
            showCancelButton: true,
            confirmButtonColor: "#3085d6",
            cancelButtonColor: "#d33",
            confirmButtonText: "Ya, Simpan",
            cancelButtonText: "Tidak"
        }).then((result) => {
            if (result.isConfirmed) {
                Swal.fire({
                    title: "Berhasil!",
                    text: "Perubahan berhasil disimpan",
                    icon: "success",
                    confirmButtonText: "OK",
                    confirmButtonColor: "#3085d6"
                }).then(() => {
                    // Submit the form setelah pesan sukses muncul
                    event.target.closest('form').submit();
                });
            }
        });
    }
    document.getElementById('nik').addEventListener('click', function() {
        if (this.readOnly) {
            document.getElementById('nik-warning').style.display = 'block';
            setTimeout(function() {
                document.getElementById('nik-warning').style.display = 'none';
            }, 3000);
        }
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laravel\sista-bijak\resources\views/create/create_migration_in.blade.php ENDPATH**/ ?>
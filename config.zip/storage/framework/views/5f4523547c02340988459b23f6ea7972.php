<?php if(session('success')): ?>
    <div class="alert alert-success">
        <?php echo e(session('success')); ?>

    </div>
<?php endif; ?>

<?php if(session('error')): ?>
    <div class="alert alert-danger">
        <?php echo e(session('error')); ?>

    </div>
<?php endif; ?>

<form action="<?php echo e(route('import.data')); ?>" method="post" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
    <div class="mb-3">
        <label for="your_file" class="form-label" style="font-weight:700;">Pilih File Excel</label>
        <input type="file" class="form-control" id="your_file" name="your_file" accept=".xlsx, .xls">
    </div>
    <button type="submit" class="btn btn-edit">Impor Data</button>
</form>
<?php /**PATH D:\laravel\sista-bijak\resources\views/import.blade.php ENDPATH**/ ?>